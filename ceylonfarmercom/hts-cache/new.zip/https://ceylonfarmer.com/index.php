<!DOCTYPE html>
<!--[if IE]><![endif]-->
<!--[if IE 8 ]><html dir="ltr" lang="en" class="ie8"><![endif]-->
<!--[if IE 9 ]><html dir="ltr" lang="en" class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html dir="ltr" lang="en">
<!--<![endif]-->
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Ceylon Farmer</title>
<base href="https://ceylonfarmer.com/" />
<meta name="description" content="Ceylon Farmer" />
<meta name="keywords" content="Ceylon Farmer" />
<script src="catalog/view/javascript/jquery/jquery-2.1.1.min.js" type="text/javascript"></script>
<link href="catalog/view/javascript/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen" />
<script src="catalog/view/javascript/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<link href="catalog/view/javascript/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="//fonts.googleapis.com/css?family=Open+Sans:400,400i,300,700" rel="stylesheet" type="text/css" />
<link href="catalog/view/theme/default/stylesheet/stylesheet.css" rel="stylesheet">
<link href="catalog/view/javascript/jquery/swiper/css/swiper.min.css" type="text/css" rel="stylesheet" media="screen" />
<link href="catalog/view/javascript/jquery/swiper/css/opencart.css" type="text/css" rel="stylesheet" media="screen" />
<script src="catalog/view/javascript/jquery/swiper/js/swiper.jquery.js" type="text/javascript"></script>
<script src="catalog/view/javascript/common.js" type="text/javascript"></script>
<link href="https://ceylonfarmer.com/image/catalog/icon.jpg" rel="icon" />
<script>
$(document).ready(function(){
    var fixedheader=$('header');
    var start=$(fixedheader).offset().top;
    $.event.add(window,'scroll',function(){
        var p=$(window).scrollTop();
        $(fixedheader).css('position',(p>start)?'fixed':'static');
        $(fixedheader).css('top',(p>start)?'0px':'');
		$(fixedheader).css('background-color',(p>start)?'#fff':'');
		$(fixedheader).css('width',(p>start)?'100%':'');
		$(fixedheader).css('z-index',(p>start)?'999':'');
		$("#search").css('top',(p>start)?'12px':'');
		$("#cart").css('top',(p>start)?'12px':'');
    }); 
});
</script>
</head>
<body>
<nav id="top">
  <div class="container cf-top-header">
    <div class="left-side"><span><i class="fa fa-phone" aria-hidden="true"></i> 0117 51 54 00</span></div>

   
    
    <div id="top-links" class="nav pull-right right-side">
      <ul class="list-inline">
        <li class="dropdown"><a href="https://ceylonfarmer.com/index.php?route=account/account" title="My Account" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <span class="hidden-xs hidden-sm hidden-md">My Account</span> <span class="caret"></span></a>
          <ul class="dropdown-menu dropdown-menu-right">
                        <li><a href="https://ceylonfarmer.com/index.php?route=account/register">Register</a></li>
            <li><a href="https://ceylonfarmer.com/index.php?route=account/login">Login</a></li>
                      </ul>
        </li>
        <li><a href="http://ceylonfarmer.com/index.php?route=checkout/cart" title="Shopping Cart"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Shopping Cart</span></a></li>
        <li><a href="https://ceylonfarmer.com/index.php?route=checkout/checkout" title="Checkout"><i class="fa fa-share"></i> <span class="hidden-xs hidden-sm hidden-md">Checkout</span></a></li>
      </ul>
    </div>
  </div>
</nav>
<header>
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <div id="logo"><a href="http://ceylonfarmer.com/index.php?route=common/home"><img src="https://ceylonfarmer.com/image/catalog/logo_ceylonfarmer.jpg" title="Ceylon Farmer" alt="Ceylon Farmer" class="img-responsive" /></a></div>
      </div>
      <div class="col-sm-5">  <div class="cf-navbar">
        			<a href="http://ceylonfarmer.com/index.php?route=product/category&amp;path=59">Vegetables</a>
        			<a href="http://ceylonfarmer.com/index.php?route=product/category&amp;path=60">Fruits</a>
          </div>
 </div>
      <div class="col-sm-3"><div id="cart" class="btn-group btn-block">
  <button type="button" data-toggle="dropdown" data-loading-text="Loading..." class="btn btn-inverse btn-block btn-lg dropdown-toggle"><i class="fa fa-shopping-cart"></i> <span id="cart-total">0 item(s) - Rs0</span></button>
  <ul class="dropdown-menu pull-right">
        <li>
      <p class="text-center">Your shopping cart is empty!</p>
    </li>
      </ul>
</div>
</div>
    </div>
  </div>
</header>


<div class="container-fluid cf-main-contain">
    
    <section class="cf-background-img"></section>

    <section class="cf-why">
        <div class="container">
            <div class="cf-why-details">
                <h1 class="cf-why-h1">Why Ceylon Farmers?</h1>
                <p class="cf-why-p">"Ceylon Farmers" brings you hand picked and packed fresh Vegetables and fruits hervested from upcountry, southern and central provinces farms to your doorstep within 24 hours!
                </p>
            </div>
        </div>
    </section>


    <secion class="cf-facts">
        <div class="container">
            <h1 class="cf-facts-h1">8 Guaranteed Perks for Your Busy Life <span>Tn fjkqfjkauh</span></h1>

            <div class="row cf-card-row">
                <div class="col-md-4">
                    <img src="img/m_img-1.png" alt="" class="img-responsive">
                </div>
                <div class="col-md-8">
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/1.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Freshness and quality in all our goods</h5>
                            <p class="cf-card-p">We bring to you the vegetables and fruits to your door within 24 hours from the time of harvest</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/2.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Save your time</h5>
                            <p class="cf-card-p">No more needless long queue, no more stuck in traffic and no more waiting! You can make your order with us anywhere. Everything is at your fingertips
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/3.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Only 100Rs. delivery to your doorstep!</h5>
                            <p class="cf-card-p">We charge only 100rs for our delivery. And our efficient drivers will drop your order to the doorstep</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/4.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">The Quality</h5>
                            <p class="cf-card-p">We transport all our goods in plastic crates to minimize damage and ensure the delivery of the quality in our produce to all our customers </p> 
                        </div>
                    </div>
                </div>
            </div>

            <div class="row cf-card-row cf-card-row-in">
                <div class="col-md-8">
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/5.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Professional and friendly staff</h5>
                            <p class="cf-card-p">We have a great trained staff force of 150 to cater to all your needs in just a click of button or even through a simple phone call. </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/6.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Guarantee money back</h5>
                            <p class="cf-card-p">Our vegetables and fruits not fresh? Don’t worry, we will give you a money back guarantee. Talk to our quality assurance team on 077 991 399 for any quality drops.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/7.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">We are available for you! </h5>
                            <p class="cf-card-p">We are available for you from 8am to 11pm. Importantly you will have an account manager to help you with all your orders.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/8.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Helping our local farmers </h5>
                            <p class="cf-card-p">We are reaching out to our local farmers from deep rural areas and helping them to benefit and sustain in their business by paying them more than the market prices. </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <img src="img/m_img-2.png" alt="" class="img-responsive">
                </div>
            </div>

            <div class="row cf-card-row">
                <div class="col-md-4">
                    <img src="img/m_img-3.png" alt="" class="img-responsive">
                </div>
                <div class="col-md-8">
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/9.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Healthy lifestyle</h5>
                            <p class="cf-card-p">Nutritious starts to degrade after harvesting and continues to, by storing them for long. Hence our goal is to deliver them to our consumer as soon as we can from the time of harvest. </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="cf-card">
                            <img src="img/10.png" alt="" class="img-responsive cf-card-no">
                            <h5 class="cf-card-header">Our Pricing</h5>
                            <p class="cf-card-p">Our prices are very competitive and it beats any supermarket prices!
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </secion>

    <div class="container cf-quote">
        <h1>Get a Quote</h1>
    </div>
    
    <section class="cf-getquote">
        <div class="container">
            <div class="cf-quote-box">
                <div class="cf-etquote-details">
                    <h2>Wfoau lvmq wiajekak yjig f.orgu f.kak .kak </h2>
                    <h3>We bring to you the vegetables and fruits to your door within 24 hours from the time of harvest 
                    </h3>
                    <div class="cf-btn">
                        <a href="#">Get A Quote</a>
                    </div>
                </div>
                <div class="cf-etquote-img">
                    <img src="img/Sanjana---02.png" alt="" class="img-responsive">
                </div>
            </div>          
        </div>
        
    </section>

       </div>
    <!-- <h1>Wfoa lvmqjd yji f.org</h1> -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>


<footer>
  <div class="container">
    <div class="row">
            <div class="col-sm-3">
        <h5>Information</h5>
        <ul class="list-unstyled">
                   <li><a href="http://ceylonfarmer.com/index.php?route=information/information&amp;information_id=7">How To Order?</a></li>
                    <li><a href="http://ceylonfarmer.com/index.php?route=information/information&amp;information_id=8">Delivery Areas</a></li>
                  </ul>
      </div>
            <div class="col-sm-3">
        <h5>Customer Service</h5>
        <ul class="list-unstyled">
          <li><a href="http://ceylonfarmer.com/index.php?route=information/contact">Contact Us</a></li>
          <!--<li><a href="https://ceylonfarmer.com/index.php?route=account/return/add">Returns</a></li> -->
          <li><a href="http://ceylonfarmer.com/index.php?route=information/sitemap">Site Map</a></li>
        </ul>
      </div>
      <div class="col-sm-3">
        
      </div>
      <div class="col-sm-3">
        <h5>My Account</h5>
        <ul class="list-unstyled">
          <li><a href="https://ceylonfarmer.com/index.php?route=account/account">My Account</a></li>
          <li><a href="https://ceylonfarmer.com/index.php?route=account/order">Order History</a></li>
         <!--<li><a href="https://ceylonfarmer.com/index.php?route=account/wishlist">Wish List</a></li>
          <li><a href="https://ceylonfarmer.com/index.php?route=account/newsletter">Newsletter</a></li> -->
        </ul>
      </div>
    </div>
    <hr>
    <p>Copyrights 2020 &copy Ceylon Farmer</p>
  </div>
</footer>
<!--
OpenCart is open source software and you are free to remove the powered by OpenCart if you want, but its generally accepted practise to make a small donation.
Please donate via PayPal to donate@opencart.com
//-->
</body></html>
<script>function priceChange(id) {
				  var x = document.getElementById('qnt'+id).value;
				  var price = document.getElementById('p'+ id).value*x;
				  document.getElementById('btn_'+id).innerHTML = '<button type="button" onclick="cartWithOption.add(this,'+id+','+x+');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add to Cart</span></button>';
				  document.getElementById('price_'+id).innerHTML = 'Rs'+price;
				};  
						var cartWithOption = {
							'add': function(clicked, product_id, quantity) {
								$.ajax({
									url: 'index.php?route=checkout/cart/add',
									type: 'post',
									data: 'product_id=' + product_id + '&quantity=' + (typeof(quantity) != 'undefined' ? quantity : 1) + '&check_for_options=true',
									dataType: 'json',
									beforeSend: function() {
										$('#cart > button').button('loading');
									},
									complete: function() {
										$('#cart > button').button('reset');
									},			
									success: function(json) {
										$('.alert, .text-danger').remove();

										if (json['show_box']) {
											$("[id^='options-for-product-']").remove();
											if(!$('#options-for-product-' + product_id).length){
												var optionsHtml = '<div class="options-for-product" id="options-for-product-' + product_id + '"><i class="fa fa-times close-options"></i><i class="fa fa-spin fa-spinner"></i><div class="loader-options"></div></div>';
												$(clicked).parents('.product-thumb').append(optionsHtml);
												if($(window).scrollTop() > $(clicked).parents('.product-thumb').offset().top){
													$('html, body').animate({
														scrollTop: ($(clicked).parents('.product-thumb').offset().top) - 50
													}, 'slow')
												}
												var optionsBox = $('#options-for-product-' + product_id);
												optionsBox.find('.loader-options').load('index.php?route=product/product&product_id=' + product_id + ' #product > *', function(){
													optionsBox.find('.loader-options').css({
														opacity: 1
													});
													optionsBox.find('.fa-spin').hide();
													
													optionsBox.find('#button-cart').attr('id', 'button-cart-options-' + product_id);
													optionsBox.find('[id^="button-upload"]').attr('id', 'options-' + optionsBox.find('[id^="button-upload"]').attr('id'));
												});
											}
										} else {
											setTimeout(function(){
												$('#cart > button').html('<i class="fa fa-shopping-cart"></i> ' + json['total']);
											}, 100);
											
												$(clicked).parent().css({"background-color": "#dff0d8", "color": "#3c763d","line-height":"3","text-align":"center","padding-top":"2","font-weight":"bold"});
												$(clicked).parent().html('<i class="fa fa-check"></i>&nbsp;Successfully Added');
												
											$('#cart > ul').load('index.php?route=common/cart/info ul li');
										}
									},
									error: function(xhr, ajaxOptions, thrownError) {
										alert(thrownError + xhr.statusText + xhr.responseText);
									}
								});
							}
						}

						$(document).on('click','[id^="button-cart-options-"]', function() {
							var t = $(this);
							var divId = '#' + t.parents('.options-for-product').attr('id');
							$.ajax({
								url: 'index.php?route=checkout/cart/add',
								type: 'post',
								data: $(divId + ' input[type=\'text\'], ' + divId + ' input[type=\'hidden\'], ' + divId + ' input[type=\'radio\']:checked, ' + divId + ' input[type=\'checkbox\']:checked, ' + divId + ' select, ' + divId + ' textarea'),
								dataType: 'json',
								beforeSend: function() {
									$('#button-cart').button('loading');
								},
								complete: function() {
									$('#button-cart').button('reset');
								},
								success: function(json) {
									$('.alert, .text-danger').remove();
									$('.form-group').removeClass('has-error');

									if (json['error']) {
										if (json['error']['option']) {
											for (i in json['error']['option']) {
												var element = $('#input-option' + i.replace('_', '-'));

												if (element.parent().hasClass('input-group')) {
													element.parent().after('<div class="text-danger">' + json['error']['option'][i] + '</div>');
												} else {
													element.after('<div class="text-danger">' + json['error']['option'][i] + '</div>');
												}
											}
										}

										if (json['error']['recurring']) {
											$('select[name=\'recurring_id\']').after('<div class="text-danger">' + json['error']['recurring'] + '</div>');
										}

										// Highlight any found errors
										$('.text-danger').parent().addClass('has-error');
									}

									if (json['success']) {
										setTimeout(function(){
											$('#cart > button').html('<i class="fa fa-shopping-cart"></i> ' + json['total']);
										}, 100);
										
											t.after('<br><div class="alert alert-success"><i class="fa fa-check-circle"></i><button type="button" class="close" data-dismiss="alert">&times;</button></div>');
											

										$('#cart > ul').load('index.php?route=common/cart/info ul li');
									}
								},
								error: function(xhr, ajaxOptions, thrownError) {
									alert(thrownError + xhr.statusText + xhr.responseText);
								}
							});
						});

						$(document).on('click', '.close-options', function(){
							$(this).parent().remove();
						});

						$(function(){
							$('[onclick^="cart.add"]').each(function(){
								$(this).attr('onclick', $(this).attr('onclick').replace('cart.add(', 'cartWithOption.add(this,'));
							});
							
							var style = 
							'<style>\
								[id^="options-for-product-"] {\
								  width:100%;\
								  height:100%;\
								  background-color:#fff;\
								  padding:15px;\
								  position:absolute;\
								  top:0;\
								  left:0;\
								  transition:0.1s opacity;\
								  z-index:999;\
								}\
								[id^="options-for-product-"] .loader-options {\
								  opacity:0;\
								}\
								[id^="options-for-product-"] .fa-spin {\
								  bottom: 0;\
								  color: #ccc;\
								  font-size: 50px;\
								  height: 50px;\
								  left: 0;\
								  margin: auto;\
								  position: absolute;\
								  right: 0;\
								  top: 0;\
								  width: 50px;\
								}\
								[id^="options-for-product-"] hr {\
								  display: none;\
								}\
								.product-thumb {\
								  position: relative;\
								  overflow: auto;\
								}\
								[id^="options-for-product-"] .close-options {\
									cursor: pointer;\
								}\
							</style>';
							$('head').append(style);
						});
					</script>